
function sumar()        {
        var Z,Y,suma,hola;

        Z=document.getElementById("sum6").value;
        Y=document.getElementById("sum9").value;
        if (isNaN(Z)||isNaN(Y)){
        hola = "Es necesario agregar numeros";
}        else{suma=parseFloat(Z)+parseFloat(Y);
hola=suma;
}

document.getElementById("sumando").innerHTML=hola;
console.log(hola);

    }